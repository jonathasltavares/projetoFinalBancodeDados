package service;

import DAO.CidadeDAO;
import model.Cidade;

public class CidadeService {
    private CidadeDAO cidadeDAO = new CidadeDAO();
    //TODO: Aqui é um exemplo de regra de negócio. possivelmente quando estivermos implementando
    // as regras de vistoria do pneu tenham regras nesse modelo de padrão de projeto.
    public void insertCidade(Cidade entidade) {
        cidadeDAO.insertCidade(entidade);
    }
}
