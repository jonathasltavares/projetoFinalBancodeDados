package service;

import DAO.EmpresaDAO;
import model.Empresa;

public class EmpresaService {
    private EmpresaDAO empresaDAO = new EmpresaDAO();
    //TODO: Aqui é um exemplo de regra de negócio. possivelmente quando estivermos implementando
    // as regras de vistoria do pneu tenham regras nesse modelo de padrão de projeto.
    public void insertEmpresa(Empresa entidade) {
        empresaDAO.insertEmpresa(entidade);
    }
}
