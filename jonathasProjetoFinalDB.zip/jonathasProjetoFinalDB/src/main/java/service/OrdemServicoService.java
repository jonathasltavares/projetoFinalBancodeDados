package service;

import DAO.OrdemServicoDAO;
import model.OrdemServico;

public class OrdemServicoService {
    private OrdemServicoDAO ordemServicoDAO = new OrdemServicoDAO();
    //TODO: Aqui é um exemplo de regra de negócio. possivelmente quando estivermos implementando
    // as regras de vistoria do pneu tenham regras nesse modelo de padrão de projeto.
    public void insertOrdemServico(OrdemServico entidade) {
        ordemServicoDAO.insertOrdemServico(entidade);
    }
}
