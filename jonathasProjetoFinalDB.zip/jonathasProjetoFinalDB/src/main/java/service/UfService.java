package service;

import DAO.UfDAO;
import model.Uf;

public class UfService {
        private UfDAO ufDAO = new UfDAO();
        //TODO: Aqui é um exemplo de regra de negócio. possivelmente quando estivermos implementando
        // as regras de vistoria do pneu tenham regras nesse modelo de padrão de projeto.
        public void insertUf(Uf entidade) {
                ufDAO.insertUf(entidade);
        }

}
