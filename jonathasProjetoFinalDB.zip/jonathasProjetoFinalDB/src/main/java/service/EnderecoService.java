package service;


import DAO.EnderecoDAO;
import model.Endereco;

public class EnderecoService {
    private EnderecoDAO enderecoDAO = new EnderecoDAO();
    //TODO: Aqui é um exemplo de regra de negócio. possivelmente quando estivermos implementando
    // as regras de vistoria do pneu tenham regras nesse modelo de padrão de projeto.
    public void insertEndereco(Endereco entidade) {
        enderecoDAO.insertEndereco(entidade);
    }
}
