package service;

import DAO.ItemOrdemServicoDAO;
import model.ItemOrdemServico;

public class ItemOrdemServicoService {
    private ItemOrdemServicoDAO itemOrdemServicoDAO = new ItemOrdemServicoDAO();
    //TODO: Aqui é um exemplo de regra de negócio. possivelmente quando estivermos implementando
    // as regras de vistoria do pneu tenham regras nesse modelo de padrão de projeto.
    public void insertItemOrdemServico(ItemOrdemServico entidade) {
        itemOrdemServicoDAO.insertItemOrdemServico(entidade);
    }
}
