package service;

import DAO.ClienteDAO;
import model.Cliente;

public class ClienteService {
    private ClienteDAO clienteDAO = new ClienteDAO();
    //TODO: Aqui é um exemplo de regra de negócio. possivelmente quando estivermos implementando
    // as regras de vistoria do pneu tenham regras nesse modelo de padrão de projeto.
    public void insertCliente(Cliente entidade) {
        clienteDAO.insertCliente(entidade);
    }
}
