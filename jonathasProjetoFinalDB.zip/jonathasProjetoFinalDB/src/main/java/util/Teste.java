package util;
import model.Uf;
import DAO.UfDAO;
import service.UfService;

import java.sql.SQLException;
import java.util.List;

public class Teste {
    public static void main(String[] args) {
        // Cria instâncias de UfDAO e ServicoUf
        UfDAO ufDAO = new UfDAO();
        UfService servicoUf = new UfService();

        try {
            // Count
            System.out.println(ufDAO.countUf());

//            // Salvar
            Uf uf = new Uf();
            uf.setDescricao("Rio de Janeiro");
            uf.setCodigo(33);
            servicoUf.insertUf(uf);

            // Deletar
//            ufDAO.deleteUf(2);
//            ufDAO.selectAllUfs().forEach(System.out::println);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

