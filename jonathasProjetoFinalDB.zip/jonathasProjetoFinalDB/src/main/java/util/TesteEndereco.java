package util;

import model.Endereco;
import DAO.EnderecoDAO;
import service.EnderecoService;

import java.sql.SQLException;
import java.util.List;

public class TesteEndereco {
    public static void main(String[] args) {
        // Cria instâncias de EnderecoDAO e ServicoEndereco
        EnderecoDAO enderecoDAO = new EnderecoDAO();
        EnderecoService servicoEndereco = new EnderecoService();

        try {
            // Count
            System.out.println(enderecoDAO.countEndereco());

            // Salvar
            Endereco endereco = new Endereco();
            endereco.setRua("Rua Teste");
            endereco.setNumero("123");
            endereco.setBairro("Bairro Teste");
            endereco.setCep("12345-678");
            endereco.setIdCidade(4);
            servicoEndereco.insertEndereco(endereco);
//
//            // Buscar por ID
//            endereco = enderecoDAO.selectEndereco(1);
//            System.out.println(endereco);
//
//            // Atualizar
//            endereco.setRua("Nova Rua");
//            enderecoDAO.updateEndereco(endereco);
//            endereco = enderecoDAO.selectEndereco(1);
//            System.out.println(endereco);
//
//            // Selecionar todas
//            List<Endereco> enderecos = enderecoDAO.selectAllEnderecos();
//            enderecos.forEach(System.out::println);
//
//            // Deletar
//            enderecoDAO.deleteEndereco(1);
//            enderecoDAO.selectAllEnderecos().forEach(System.out::println);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

