package util;

import model.ItemOrdemServico;
import DAO.ItemOrdemServicoDAO;
import service.ItemOrdemServicoService;

import java.sql.SQLException;
import java.util.List;

public class TesteItemOrdemServico {
    public static void main(String[] args) {
        // Cria instâncias de ItemOrdemServicoDAO e ServicoItemOrdemServico
        ItemOrdemServicoDAO itemOrdemServicoDAO = new ItemOrdemServicoDAO();
        ItemOrdemServicoService servicoItemOrdemServico = new ItemOrdemServicoService();

        try {
            // Count
            System.out.println(itemOrdemServicoDAO.countItemOrdemServico());

//            // Salvar
            ItemOrdemServico itemOrdemServico = new ItemOrdemServico();
//            itemOrdemServico.setDescricao("Troca de óleo");
//            itemOrdemServico.setPreco(50000L);
//            itemOrdemServico.setIdOrdemServico(1);
//            servicoItemOrdemServico.insertItemOrdemServico(itemOrdemServico);

            // Buscar por ID
            itemOrdemServico = itemOrdemServicoDAO.selectItemOrdemServico(1); // Substitua pelo ID do item criado
            System.out.println(itemOrdemServico);
//
//            // Atualizar
//            itemOrdemServico.setDescricao("Troca de filtro de óleo");
//            itemOrdemServicoDAO.updateItemOrdemServico(itemOrdemServico);
//            itemOrdemServico = itemOrdemServicoDAO.selectItemOrdemServico(1);
//            System.out.println(itemOrdemServico);
//
//            // Selecionar todas
//            List<ItemOrdemServico> itensOrdemServico = itemOrdemServicoDAO.selectAllItensOrdemServico();
//            itensOrdemServico.forEach(System.out::println);
//
//            // Deletar
//            itemOrdemServicoDAO.deleteItemOrdemServico(1);
//            itemOrdemServicoDAO.selectAllItensOrdemServico().forEach(System.out::println);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
