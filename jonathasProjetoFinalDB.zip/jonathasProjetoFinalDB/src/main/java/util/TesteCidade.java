package util;
import model.Cidade;
import DAO.CidadeDAO;
import service.CidadeService;

import java.sql.SQLException;
import java.util.List;

public class TesteCidade {
    public static void main(String[] args) {
        // Cria instâncias de CidadeDAO e ServicoCidade
        CidadeDAO cidadeDAO = new CidadeDAO();
        CidadeService servicoCidade = new CidadeService();

        try {
//            // Count
//            System.out.println(cidadeDAO.countCidade());
//
            // Salvar
            Cidade cidade = new Cidade();
//            cidade.setDescricao("Rio de Janeiro");
//            cidade.setCodigo(3304557);
//            cidade.setIdUf(4);
//            servicoCidade.insertCidade(cidade);
//
            // Buscar por ID
            cidade = cidadeDAO.selectCidade(4);
            System.out.println(cidade);
//
//            // Atualizar
//            cidade.setDescricao("São Paulo");
//            cidade.setCodigo(3550308);
//            cidadeDAO.updateCidade(cidade);
//            cidade = cidadeDAO.selectCidade(3);
//            System.out.println(cidade);
//
//            // Selecionar todas
//            List<Cidade> cidades = cidadeDAO.selectAllCidades();
//            cidades.forEach(System.out::println);

            // Deletar
//            cidadeDAO.deleteCidade(3);
//            cidadeDAO.selectAllCidades().forEach(System.out::println);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
