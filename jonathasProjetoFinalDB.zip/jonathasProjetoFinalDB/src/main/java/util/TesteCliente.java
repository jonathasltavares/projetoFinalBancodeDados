package util;
import model.Cliente;
import DAO.ClienteDAO;
import service.ClienteService;

import java.sql.SQLException;
import java.util.List;

public class TesteCliente {
    public static void main(String[] args) {
        // Cria instâncias de ClienteDAO e ServicoCliente
        ClienteDAO clienteDAO = new ClienteDAO();
        ClienteService servicoCliente = new ClienteService();

        try {
            // Count
            System.out.println(clienteDAO.countCliente());

            // Salvar
            Cliente cliente = new Cliente();
            cliente.setNome("Maria");
            cliente.setDtNascimento("01-01-1991");
            cliente.setCpf("12345678901");
            cliente.setEmail("maria@example.com");
            cliente.setIdEndereco(1);
            servicoCliente.insertCliente(cliente);

//            // Buscar por ID
//            cliente = clienteDAO.selectCliente(1);
//            System.out.println(cliente);
//
//            // Atualizar
//            cliente.setNome("João");
//            clienteDAO.updateCliente(cliente);
//            cliente = clienteDAO.selectCliente(1);
//            System.out.println(cliente);
//
//            // Selecionar todas
//            List<Cliente> clientes = clienteDAO.selectAllClientes();
//            clientes.forEach(System.out::println);
//
//            // Deletar
//            clienteDAO.deleteCliente(2);
//            clienteDAO.selectAllClientes().forEach(System.out::println);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

