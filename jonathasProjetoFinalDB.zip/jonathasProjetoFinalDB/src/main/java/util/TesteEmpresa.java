package util;

import model.Empresa;
import DAO.EmpresaDAO;
import service.EmpresaService;

import java.sql.SQLException;
import java.util.List;

public class TesteEmpresa {
    public static void main(String[] args) {
        // Cria instâncias de EmpresaDAO e ServicoEmpresa
        EmpresaDAO empresaDAO = new EmpresaDAO();
        EmpresaService servicoEmpresa = new EmpresaService();

        try {
            // Count
            System.out.println(empresaDAO.countEmpresa());

            // Salvar
            Empresa empresa = new Empresa();
            empresa.setNomeFantasia("Empresa Teste");
            empresa.setCnpj("12345678901234");
            empresa.setSlogan("Nosso Slogan");
            empresa.setLogo(null);
            empresa.setIdEndereco(1);
            servicoEmpresa.insertEmpresa(empresa);

//            // Buscar por ID
//            empresa = empresaDAO.selectEmpresa(1);
//            System.out.println(empresa);
//
//            // Atualizar
//            empresa.setNomeFantasia("Nova Empresa");
//            empresaDAO.updateEmpresa(empresa);
//            empresa = empresaDAO.selectEmpresa(1);
//            System.out.println(empresa);
//
//            // Selecionar todas
//            List<Empresa> empresas = empresaDAO.selectAllEmpresas();
//            empresas.forEach(System.out::println);
//
//            // Deletar
//            empresaDAO.deleteEmpresa(1);
//            empresaDAO.selectAllEmpresas().forEach(System.out::println);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
