package util;

import model.OrdemServico;
import DAO.OrdemServicoDAO;
import service.OrdemServicoService;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

public class TesteOrdemServico {
    public static void main(String[] args) {
        // Cria instâncias de OrdemServicoDAO e ServicoOrdemServico
        OrdemServicoDAO ordemServicoDAO = new OrdemServicoDAO();
        OrdemServicoService servicoOrdemServico = new OrdemServicoService();

        try {
            // Count
            System.out.println(ordemServicoDAO.countOrdemServico());

            // Salvar
            OrdemServico ordemServico = new OrdemServico();
            ordemServico.setObservacao("Serviço de reparo");
            ordemServico.setDtAbertura(new Timestamp(System.currentTimeMillis()));
            ordemServico.setDtSaida(null);
            ordemServico.setUsernameResponsavel("usuario123");
            ordemServico.setIdCliente(3);
            ordemServico.setIdEmpresa(1);
            servicoOrdemServico.insertOrdemServico(ordemServico);

//            // Buscar por ID
//            ordemServico = ordemServicoDAO.selectOrdemServico(1); // Substitua pelo ID da ordem de serviço criada
//            System.out.println(ordemServico);
//
//            // Atualizar
//            ordemServico.setObservacao("Serviço de manutenção");
//            ordemServicoDAO.updateOrdemServico(ordemServico);
//            ordemServico = ordemServicoDAO.selectOrdemServico(1);
//            System.out.println(ordemServico);
//
//            // Selecionar todas
//            List<OrdemServico> ordensServico = ordemServicoDAO.selectAllOrdensServico();
//            ordensServico.forEach(System.out::println);
//
//            // Deletar
//            ordemServicoDAO.deleteOrdemServico(1);
//            ordemServicoDAO.selectAllOrdensServico().forEach(System.out::println);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
